package io.meshk.milton.expresscommand;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpressCommandApplicationTests {

	@Test
	void contextLoads() {
	}

}
